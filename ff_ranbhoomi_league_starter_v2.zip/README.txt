FF RANBHOOMI LEAGUE — Starter project

Folders:
- website: responsive homepage prototype
- mobile: Flutter Android app starter
- backend: Express API starter

WEBSITE:
Open website/index.html in a browser.

BACKEND:
Install Node.js, then open a terminal in backend and run:
  npm install
  npm run dev
API:
  http://localhost:4000/api/health
  http://localhost:4000/api/tournaments

ANDROID:
Install Flutter SDK and Android Studio. In the mobile folder run:
  flutter create .
Then ensure lib/main.dart is the supplied starter and run:
  flutter run

This is starter/demo code, not a production-ready service. Login, persistent database, real registration and payment flows are not implemented. Do not enable paid entry or cash prizes until applicable legal and platform requirements have been reviewed.
